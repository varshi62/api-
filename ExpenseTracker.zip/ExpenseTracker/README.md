# 💰 Personal Expense Tracker (Java CLI)

A simple Java-based command-line application to track personal expenses.

## 🚀 Features

- Add and view categorized expenses
- Calculate total and monthly spending
- Save/load from CSV file

## 📦 Tech Stack

- Java SE 8+
- File I/O
- OOP
- CLI interface

## 🛠️ Compile and Run

```bash
javac -d out src/**/*.java
java -cp out ui.Main
```

## 📝 Author

Made for practice and GitHub mini-project purposes.
