package util;

import model.Expense;
import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FileHandler {
    private static final String FILE_NAME = "expenses.csv";

    public static List<Expense> loadExpenses() {
        List<Expense> expenses = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                Expense e = new Expense(parts[0], Double.parseDouble(parts[1]), parts[2], LocalDate.parse(parts[3]));
                expenses.add(e);
            }
        } catch (IOException e) {
            System.out.println("Error loading file: " + e.getMessage());
        }
        return expenses;
    }

    public static void saveExpenses(List<Expense> expenses) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Expense e : expenses) {
                String line = String.join(",", e.getDescription(),
                        String.valueOf(e.getAmount()), e.getCategory(), e.getDate().toString());
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
    }
}
