package ui;

import model.Expense;
import service.ExpenseManager;
import util.FileHandler;

import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ExpenseManager manager = new ExpenseManager();
        manager.getAllExpenses().addAll(FileHandler.loadExpenses());

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Personal Expense Tracker ---");
            System.out.println("1. Add Expense");
            System.out.println("2. View All Expenses");
            System.out.println("3. View Total");
            System.out.println("4. View Monthly");
            System.out.println("5. Save & Exit");
            System.out.print("Choose: ");

            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1 -> {
                    System.out.print("Description: ");
                    String desc = sc.nextLine();
                    System.out.print("Amount: ");
                    double amt = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Category: ");
                    String cat = sc.nextLine();
                    Expense e = new Expense(desc, amt, cat, LocalDate.now());
                    manager.addExpense(e);
                    System.out.println("Expense added.");
                }
                case 2 -> {
                    System.out.println("--- All Expenses ---");
                    for (Expense e : manager.getAllExpenses()) {
                        System.out.println(e);
                    }
                }
                case 3 -> System.out.println("Total: $" + manager.getTotalExpenses());
                case 4 -> {
                    System.out.print("Enter month (1-12): ");
                    int m = sc.nextInt();
                    Month month = Month.of(m);
                    System.out.println("Monthly Total: $" + manager.getMonthlyExpenses(month));
                }
                case 5 -> {
                    FileHandler.saveExpenses(manager.getAllExpenses());
                    System.out.println("Saved and exiting...");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }
}
