package service;

import model.Expense;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public class ExpenseManager {
    private List<Expense> expenses = new ArrayList<>();

    public void addExpense(Expense e) { expenses.add(e); }
    public List<Expense> getAllExpenses() { return expenses; }
    public double getTotalExpenses() {
        return expenses.stream().mapToDouble(Expense::getAmount).sum();
    }
    public double getMonthlyExpenses(Month month) {
        return expenses.stream()
            .filter(e -> e.getDate().getMonth() == month)
            .mapToDouble(Expense::getAmount).sum();
    }
    public void clearExpenses() { expenses.clear(); }
}
